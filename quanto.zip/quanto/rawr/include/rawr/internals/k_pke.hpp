#pragma once
#include "rawr/internals/math/field.hpp"
#include "rawr/internals/poly/compression.hpp"
#include "rawr/internals/poly/ntt.hpp"
#include "rawr/internals/poly/poly_vec.hpp"
#include "rawr/internals/poly/sampling.hpp"
#include "rawr/internals/poly/serialize.hpp"
#include "rawr/internals/utility/params.hpp"
#include "rawr/internals/utility/utils.hpp"
#include "sha3/sha3_512.hpp"
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>

// Public Key Encryption Scheme
namespace k_pke {

// K-PKE key generation algorithm, generating byte serialized public key and secret keym given a 32 -bytes input seed `d`.
// See algorithm 13 of K-PKE specification https://doi.org/10.6028/NIST.FIPS.203.
template<size_t k, size_t eta1>
constexpr void
keygen(std::span<const uint8_t, 32> d,
       std::span<uint8_t, rawr_utils::get_pke_public_key_len(k)> pubkey,
       std::span<uint8_t, rawr_utils::get_pke_secret_key_len(k)> seckey)
  requires(rawr_params::check_keygen_params(k, eta1))
{
  std::array<uint8_t, 64> g_out{};
  auto g_out_span = std::span(g_out);

  // Repurposing `g_out` (i.e. array for holding output of hash function G),
  // for preparing the concatenated input to hash function G.
  std::copy(d.begin(), d.end(), g_out_span.begin());
  g_out_span[d.size()] = k; // Domain seperator to prevent misuse of key

  sha3_512::sha3_512_t h512;
  h512.absorb(g_out_span.template first<d.size() + 1>());
  h512.finalize();
  h512.digest(g_out_span);

  const auto rho = g_out_span.template subspan<0, 32>();
  const auto sigma = g_out_span.template subspan<rho.size(), 32>();

  std::array<rawr_field::zq_t, k * k * rawr_ntt::N> A_prime{};
  rawr_utils::generate_matrix<k, false>(A_prime, rho);

  uint8_t N = 0;

  std::array<rawr_field::zq_t, k * rawr_ntt::N> s{};
  rawr_utils::generate_vector<k, eta1>(s, sigma, N);
  N += k;

  std::array<rawr_field::zq_t, k * rawr_ntt::N> e{};
  rawr_utils::generate_vector<k, eta1>(e, sigma, N);
  N += k;

  rawr_utils::poly_vec_ntt<k>(s);
  rawr_utils::poly_vec_ntt<k>(e);

  std::array<rawr_field::zq_t, k * rawr_ntt::N> t_prime{};

  rawr_utils::matrix_multiply<k, k, k, 1>(A_prime, s, t_prime);
  rawr_utils::poly_vec_add_to<k>(e, t_prime);

  constexpr size_t pubkey_offset = k * 12 * 32;
  auto encoded_t_prime_in_pubkey = pubkey.template subspan<0, pubkey_offset>();
  auto rho_in_pubkey = pubkey.template subspan<pubkey_offset, 32>();

  rawr_utils::poly_vec_encode<k, 12>(t_prime, encoded_t_prime_in_pubkey);
  std::copy(rho.begin(), rho.end(), rho_in_pubkey.begin());
  rawr_utils::poly_vec_encode<k, 12>(s, seckey);

  rawr_utils::secure_zeroize(g_out);
  rawr_utils::secure_zeroize(s);
  rawr_utils::secure_zeroize(e);
}

// Given a *valid* K-PKE public key, 32 -bytes message ( to be encrypted ) and 32 -bytes random coin
// ( from where all randomness is deterministically sampled ), this routine encrypts message using
// K-PKE encryption algorithm, computing compressed cipher text.
//
// If modulus check, as described in point (2) of section 7.2 of RAWR standard, fails, it returns false.
//
// See algorithm 14 of K-PKE specification https://doi.org/10.6028/NIST.FIPS.203.
template<size_t k, size_t eta1, size_t eta2, size_t du, size_t dv>
[[nodiscard("Use result of modulus check on public key")]] constexpr bool
encrypt(std::span<const uint8_t, rawr_utils::get_pke_public_key_len(k)> pubkey,
        std::span<const uint8_t, 32> msg,
        std::span<const uint8_t, 32> rcoin,
        std::span<uint8_t, rawr_utils::get_pke_cipher_text_len(k, du, dv)> ctxt)
  requires(rawr_params::check_encrypt_params(k, eta1, eta2, du, dv))
{
  constexpr size_t pkoff = k * 12 * 32;
  auto encoded_t_prime_in_pubkey = pubkey.template subspan<0, pkoff>();
  auto rho = pubkey.template subspan<pkoff, 32>();

  std::array<rawr_field::zq_t, k * rawr_ntt::N> t_prime{};
  std::array<uint8_t, encoded_t_prime_in_pubkey.size()> encoded_tprime{};

  rawr_utils::poly_vec_decode<k, 12>(encoded_t_prime_in_pubkey, t_prime);
  rawr_utils::poly_vec_encode<k, 12>(t_prime, encoded_tprime);

  using encoded_pkey_t = std::span<const uint8_t, encoded_t_prime_in_pubkey.size()>;
  const auto are_equal = rawr_utils::ct_memcmp(encoded_pkey_t(encoded_t_prime_in_pubkey), encoded_pkey_t(encoded_tprime));
  if (are_equal == 0U) {
    // Got an invalid public key
    return false;
  }

  std::array<rawr_field::zq_t, k * k * rawr_ntt::N> A_prime{};
  rawr_utils::generate_matrix<k, true>(A_prime, rho);

  uint8_t N = 0;

  std::array<rawr_field::zq_t, k * rawr_ntt::N> r{};
  rawr_utils::generate_vector<k, eta1>(r, rcoin, N);
  N += k;

  std::array<rawr_field::zq_t, k * rawr_ntt::N> e1{};
  rawr_utils::generate_vector<k, eta2>(e1, rcoin, N);
  N += k;

  std::array<rawr_field::zq_t, rawr_ntt::N> e2{};
  rawr_utils::generate_vector<1, eta2>(e2, rcoin, N);

  rawr_utils::poly_vec_ntt<k>(r);

  std::array<rawr_field::zq_t, k * rawr_ntt::N> u{};

  rawr_utils::matrix_multiply<k, k, k, 1>(A_prime, r, u);
  rawr_utils::poly_vec_intt<k>(u);
  rawr_utils::poly_vec_add_to<k>(e1, u);

  std::array<rawr_field::zq_t, rawr_ntt::N> v{};

  rawr_utils::matrix_multiply<1, k, k, 1>(t_prime, r, v);
  rawr_utils::poly_vec_intt<1>(v);
  rawr_utils::poly_vec_add_to<1>(e2, v);

  std::array<rawr_field::zq_t, rawr_ntt::N> m{};
  rawr_utils::decode<1>(msg, m);
  rawr_utils::poly_decompress<1>(m);
  rawr_utils::poly_vec_add_to<1>(m, v);

  constexpr size_t ctxt_offset = k * du * 32;
  auto polyvec_u_in_ctxt = ctxt.template first<ctxt_offset>();
  auto poly_v_in_ctxt = ctxt.template last<dv * 32>();

  rawr_utils::poly_vec_compress<k, du>(u);
  rawr_utils::poly_vec_encode<k, du>(u, polyvec_u_in_ctxt);

  rawr_utils::poly_compress<dv>(v);
  rawr_utils::encode<dv>(v, poly_v_in_ctxt);

  rawr_utils::secure_zeroize(r);
  rawr_utils::secure_zeroize(e1);
  rawr_utils::secure_zeroize(e2);
  rawr_utils::secure_zeroize(m);

  return true;
}

// Given K-PKE secret key and cipher text, this routine recovers 32 -bytes plain text which
// was encrypted using K-PKE public key i.e. associated with this secret key.
//
// See algorithm 15 defined in K-PKE specification https://doi.org/10.6028/NIST.FIPS.203.
template<size_t k, size_t du, size_t dv>
constexpr void
decrypt(std::span<const uint8_t, rawr_utils::get_pke_secret_key_len(k)> seckey,
        std::span<const uint8_t, rawr_utils::get_pke_cipher_text_len(k, du, dv)> ctxt,
        std::span<uint8_t, 32> ptxt)
  requires(rawr_params::check_decrypt_params(k, du, dv))
{
  constexpr size_t ctxt_offset = k * du * 32;
  auto polyvec_u_in_ctxt = ctxt.template subspan<0, ctxt_offset>();
  auto poly_v_in_ctxt = ctxt.template subspan<ctxt_offset, dv * 32>();

  std::array<rawr_field::zq_t, k * rawr_ntt::N> u{};
  std::array<rawr_field::zq_t, rawr_ntt::N> v{};

  rawr_utils::poly_vec_decode<k, du>(polyvec_u_in_ctxt, u);
  rawr_utils::poly_vec_decompress<k, du>(u);

  rawr_utils::decode<dv>(poly_v_in_ctxt, v);
  rawr_utils::poly_decompress<dv>(v);

  std::array<rawr_field::zq_t, k * rawr_ntt::N> s_prime{};
  rawr_utils::poly_vec_decode<k, 12>(seckey, s_prime);

  rawr_utils::poly_vec_ntt<k>(u);

  std::array<rawr_field::zq_t, rawr_ntt::N> t{};

  rawr_utils::matrix_multiply<1, k, k, 1>(s_prime, u, t);
  rawr_utils::poly_vec_intt<1>(t);
  rawr_utils::poly_vec_sub_from<1>(t, v);

  rawr_utils::poly_compress<1>(v);
  rawr_utils::encode<1>(v, ptxt);

  rawr_utils::secure_zeroize(s_prime);
}

}
