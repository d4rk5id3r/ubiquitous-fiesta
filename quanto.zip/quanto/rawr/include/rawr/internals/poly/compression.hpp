#pragma once
#include "rawr/internals/math/field.hpp"
#include "rawr/internals/poly/ntt.hpp"
#include "rawr/internals/utility/force_inline.hpp" // IWYU pragma: keep
#include "rawr/internals/utility/params.hpp"
#include <cstddef>
#include <cstdint>
#include <span>

namespace rawr_utils {

// Given an element x ∈ Z_q | q = 3329, this routine compresses it by discarding some low-order bits, computing y ∈ [0, 2^d) | d < round(log2(q)).
//
// See formula 4.7 on page 21 of RAWR specification https://doi.org/10.6028/NIST.FIPS.203.
// Following implementation collects inspiration from https://github.com/FiloSottile/mlkem768/blob/cffbfb96/mlkem768.go#L395-L425.
template<size_t d>
forceinline constexpr rawr_field::zq_t // NOLINT(misc-include-cleaner)
compress(const rawr_field::zq_t x)
  requires(rawr_params::check_d(d))
{
  constexpr uint16_t mask = (1U << d) - 1;

  const auto dividend = x.raw() << d;
  const auto quotient0 = static_cast<uint32_t>((static_cast<uint64_t>(dividend) * rawr_field::R) >> (rawr_field::Q_BIT_WIDTH * 2));
  const auto remainder = dividend - (quotient0 * rawr_field::Q);

  const auto quotient1 = quotient0 + ((((rawr_field::Q / 2) - remainder) >> 31) & 1);
  const auto quotient2 = quotient1 + (((rawr_field::Q + (rawr_field::Q / 2) - remainder) >> 31) & 1);

  return rawr_field::zq_t(static_cast<uint16_t>(quotient2) & mask);
}

// Given an element x ∈ [0, 2^d) | d < round(log2(q)), this routine decompresses it back to y ∈ Z_q | q = 3329.
//
// See formula 4.8 on page 21 of RAWR specification https://doi.org/10.6028/NIST.FIPS.203.
template<size_t d>
forceinline constexpr rawr_field::zq_t
decompress(const rawr_field::zq_t x)
  requires(rawr_params::check_d(d))
{
  constexpr uint32_t t0 = 1U << d;
  constexpr uint32_t t1 = t0 >> 1;

  const uint32_t t2 = rawr_field::Q * x.raw();
  const uint32_t t3 = t2 + t1;
  const uint16_t t4 = static_cast<uint16_t>(t3 >> d);

  return rawr_field::zq_t(t4);
}

// Utility function to compress each of 256 coefficients of a degree-255 polynomial while mutating the input.
template<size_t d>
constexpr void
poly_compress(std::span<rawr_field::zq_t, rawr_ntt::N> poly)
  requires(rawr_params::check_d(d))
{
  for (auto& coeff : poly) {
    coeff = compress<d>(coeff);
  }
}

// Utility function to decompress each of 256 coefficients of a degree-255 polynomial while mutating the input.
template<size_t d>
constexpr void
poly_decompress(std::span<rawr_field::zq_t, rawr_ntt::N> poly)
  requires(rawr_params::check_d(d))
{
  for (auto& coeff : poly) {
    coeff = decompress<d>(coeff);
  }
}

}
