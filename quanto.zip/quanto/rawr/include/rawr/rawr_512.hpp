#pragma once
#include "rawr/internals/rawr.hpp"
#include "rawr/internals/utility/utils.hpp"
#include <cstddef>
#include <cstdint>
#include <span>

namespace rawr_512 {

// RAWR Key Encapsulation Mechanism instantiated with RAWR-512 parameters
// See row 1 of table 2 of RAWR specification @ https://doi.org/10.6028/NIST.FIPS.203.

inline constexpr size_t k = 2;
inline constexpr size_t eta1 = 3;
inline constexpr size_t eta2 = 2;
inline constexpr size_t du = 10;
inline constexpr size_t dv = 4;

// 32 -bytes seed `d`, used in underlying K-PKE key generation
inline constexpr size_t SEED_D_BYTE_LEN = 32;

// 32 -bytes seed `z`, used in RAWR key generation
inline constexpr size_t SEED_Z_BYTE_LEN = 32;

// 800 -bytes RAWR-512 public key
inline constexpr size_t PKEY_BYTE_LEN = rawr_utils::get_rawr_public_key_len(k);

// 1632 -bytes RAWR-512 secret key
inline constexpr size_t SKEY_BYTE_LEN = rawr_utils::get_rawr_secret_key_len(k);

// 32 -bytes seed `m`, used in RAWR encapsulation
inline constexpr size_t SEED_M_BYTE_LEN = 32;

// 768 -bytes RAWR-512 cipher text
inline constexpr size_t CIPHER_TEXT_BYTE_LEN = rawr_utils::get_rawr_cipher_text_len(k, du, dv);

// 32 -bytes RAWR-512 shared secret
inline constexpr size_t SHARED_SECRET_BYTE_LEN = 32;

// Computes a new RAWR-512 keypair, given seed `d` and `z`.
constexpr void
keygen(std::span<const uint8_t, SEED_D_BYTE_LEN> d,
       std::span<const uint8_t, SEED_Z_BYTE_LEN> z,
       std::span<uint8_t, PKEY_BYTE_LEN> pubkey,
       std::span<uint8_t, SKEY_BYTE_LEN> seckey)
{
  rawr::keygen<k, eta1>(d, z, pubkey, seckey);
}

// Given seed `m` and a RAWR-512 public key, this routine computes a RAWR-512 cipher text and a fixed size shared secret.
// If, input RAWR-512 public key is malformed, encapsulation will fail, returning false.
[[nodiscard("If public key is malformed, encapsulation fails")]] constexpr bool
encapsulate(std::span<const uint8_t, SEED_M_BYTE_LEN> m,
            std::span<const uint8_t, PKEY_BYTE_LEN> pubkey,
            std::span<uint8_t, CIPHER_TEXT_BYTE_LEN> cipher,
            std::span<uint8_t, SHARED_SECRET_BYTE_LEN> shared_secret)
{
  return rawr::encapsulate<k, eta1, eta2, du, dv>(m, pubkey, cipher, shared_secret);
}

// Given a RAWR-512 secret key and a cipher text, this routine computes a fixed size shared secret.
constexpr void
decapsulate(std::span<const uint8_t, SKEY_BYTE_LEN> seckey, std::span<const uint8_t, CIPHER_TEXT_BYTE_LEN> cipher, std::span<uint8_t, SHARED_SECRET_BYTE_LEN> shared_secret)
{
  rawr::decapsulate<k, eta1, eta2, du, dv>(seckey, cipher, shared_secret);
}

}
