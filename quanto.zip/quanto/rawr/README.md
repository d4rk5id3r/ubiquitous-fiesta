# RAWR!

```
                                                                                                             
                                                                                                             
RRRRRRRRRRRRRRRRR                  AAA   WWWWWWWW                           WWWWWWWWRRRRRRRRRRRRRRRRR    !!! 
R::::::::::::::::R                A:::A  W::::::W                           W::::::WR::::::::::::::::R  !!:!!
R::::::RRRRRR:::::R              A:::::A W::::::W                           W::::::WR::::::RRRRRR:::::R !:::!
RR:::::R     R:::::R            A:::::::AW::::::W                           W::::::WRR:::::R     R:::::R!:::!
  R::::R     R:::::R           A:::::::::AW:::::W           WWWWW           W:::::W   R::::R     R:::::R!:::!
  R::::R     R:::::R          A:::::A:::::AW:::::W         W:::::W         W:::::W    R::::R     R:::::R!:::!
  R::::RRRRRR:::::R          A:::::A A:::::AW:::::W       W:::::::W       W:::::W     R::::RRRRRR:::::R !:::!
  R:::::::::::::RR          A:::::A   A:::::AW:::::W     W:::::::::W     W:::::W      R:::::::::::::RR  !:::!
  R::::RRRRRR:::::R        A:::::A     A:::::AW:::::W   W:::::W:::::W   W:::::W       R::::RRRRRR:::::R !:::!
  R::::R     R:::::R      A:::::AAAAAAAAA:::::AW:::::W W:::::W W:::::W W:::::W        R::::R     R:::::R!:::!
  R::::R     R:::::R     A:::::::::::::::::::::AW:::::W:::::W   W:::::W:::::W         R::::R     R:::::R!!:!!
  R::::R     R:::::R    A:::::AAAAAAAAAAAAA:::::AW:::::::::W     W:::::::::W          R::::R     R:::::R !!! 
RR:::::R     R:::::R   A:::::A             A:::::AW:::::::W       W:::::::W         RR:::::R     R:::::R     
R::::::R     R:::::R  A:::::A               A:::::AW:::::W         W:::::W          R::::::R     R:::::R !!! 
R::::::R     R:::::R A:::::A                 A:::::AW:::W           W:::W           R::::::R     R:::::R!!:!!
RRRRRRRR     RRRRRRRAAAAAAA                   AAAAAAAWWW             WWW            RRRRRRRR     RRRRRRR !!! 
                                                                                                             
                                                                                                             
                                                                                                             
                                                                                                             
                                                                                                             
                                                                                                             
                                                                                                             
```
