#include "rawr/rawr_1024.hpp"
#include "randomshake/randomshake.hpp"
#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <cstring>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <string>
#include <cstdlib>
#include <iostream>
#include <iomanip>
 

#define AES_GCM_NONCE_SIZE 12
#define NR_OF_MESSAGES 1000
#define NR_OF_SEEDS 100

inline std::string bytes_to_hex(std::span<const uint8_t> bytes) {
  std::stringstream ss;
  ss << std::hex;

  for (const auto byte : bytes) {
    ss << std::setw(2) << std::setfill('0') << (unsigned int)(unsigned char)(byte);
  }

  return ss.str();
}

std::string string_to_hex(const std::string& input)
{
  std::stringstream ss;
  ss << std::hex;

  for (size_t i = 0; i < input.size(); ++i) {
    ss << std::setw(2) << std::setfill('0') << (unsigned int)(unsigned char)(input[i]);
  }

  return ss.str();
}

// credits to https://gist.github.com/Erykor/ba7a5c394b506887150a76bc52ffb98c
inline bool aes_gcm_encrypt(const unsigned char *in, size_t in_size,
                          unsigned char *out, size_t *out_size,
                          const unsigned char *key) {
  unsigned char iv[AES_GCM_NONCE_SIZE];
  unsigned char tag[AES_BLOCK_SIZE];

  RAND_bytes(iv, AES_GCM_NONCE_SIZE);
  memcpy(out, iv, AES_GCM_NONCE_SIZE);
  out += AES_GCM_NONCE_SIZE;

  int actual_size{0};
  int final_size{0};

  EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
  EVP_EncryptInit(ctx, EVP_aes_256_gcm(), key, iv);

  EVP_EncryptUpdate(ctx, out, &actual_size, in, in_size);

  if (actual_size >= 0 && (size_t) actual_size != in_size) {
    std::cerr << "AES.GCM encryption error!" << std::endl;
    std::abort();
  }

  out += in_size;

  EVP_EncryptFinal(ctx, out, &final_size);
  EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AES_BLOCK_SIZE, tag);

  memcpy(out, tag, AES_BLOCK_SIZE);

  *out_size = AES_BLOCK_SIZE + AES_GCM_NONCE_SIZE + actual_size + final_size;

  EVP_CIPHER_CTX_free(ctx);

  return true;
}

// Adapted from https://gist.github.com/Erykor/ba7a5c394b506887150a76bc52ffb98c
inline bool aes_gcm_encrypt(const std::string &in, std::string *out,
                          const unsigned char *key) {
  out->resize(in.size() + AES_BLOCK_SIZE + AES_GCM_NONCE_SIZE);

  size_t out_size;
  if (!aes_gcm_encrypt(
          reinterpret_cast<const unsigned char *>(in.data()), in.size(),
          reinterpret_cast<unsigned char *>(out->data()), &out_size,
          key)) {
    return false;
  }
  out->resize(out_size);

  return true;
}

int main() {
  const char* flag = std::getenv("FLAG");
  if (flag == NULL) {
    std::cout << "Must set env variable FLAG." << "\n";
    return 1;
  }

  std::array<std::array<uint8_t, rawr_1024::SEED_D_BYTE_LEN>, NR_OF_SEEDS> seed_ds{};
  std::array<std::array<uint8_t, rawr_1024::SEED_Z_BYTE_LEN>, NR_OF_SEEDS> seed_zs{};
  std::array<std::array<uint8_t, rawr_1024::SEED_M_BYTE_LEN>, NR_OF_SEEDS> seed_ms{};

  std::array<uint8_t, rawr_1024::PKEY_BYTE_LEN> ek{};
  std::array<uint8_t, rawr_1024::SKEY_BYTE_LEN> dk{};
  std::array<uint8_t, rawr_1024::CIPHER_TEXT_BYTE_LEN> ct{};
  std::array<uint8_t, rawr_1024::SHARED_SECRET_BYTE_LEN>
      shared_secret_sender{};

  // More keys, more security :)
  randomshake::randomshake_t csprng{};
  for (uint64_t i = 0; i < NR_OF_SEEDS; ++i) {
    csprng.generate(seed_ds[i]);
    csprng.generate(seed_zs[i]);
    csprng.generate(seed_ms[i]);
  }

  // Pick one index for the cosmic ray to hit
  std::uniform_int_distribution<uint64_t> cosmic_dist{ 0, NR_OF_MESSAGES - 1 };
  uint64_t cosmic_ray_idx = cosmic_dist(csprng);

  std::uniform_int_distribution<uint64_t> seed_dist{ 0, NR_OF_SEEDS - 1 };
  uint64_t seed_idx;

  std::string out;

  for (uint64_t i = 0; i < NR_OF_MESSAGES; ++i) {
    seed_idx = seed_dist(csprng);
  
    if (i == cosmic_ray_idx) {
      // same as else branch, but oh no! A cosmic ray hit us during communication!
      // Probably nothing went wrong, I'll just continue.
      // (No cosmic rays are distributed with this program, make your own...)
      continue;
    }
    else {
      rawr_1024::keygen(seed_ds[seed_idx], seed_zs[seed_idx], ek, dk);
      assert(rawr_1024::encapsulate(seed_ms[seed_idx], ek, ct, shared_secret_sender));
    }

    std::string in = "RAWR*" + std::to_string(i) + "! " + flag;
    assert(aes_gcm_encrypt(in, &out, (const uint8_t *) &shared_secret_sender));
    
    std::cout << "[Quantosaurus 1 to quantosaurus 2] ek: " << bytes_to_hex(ek) << "\n";
    std::cout << "[Quantosaurus 2 to quantosaurus 1] ct: " << bytes_to_hex(ct) << ", rawr: " << string_to_hex(out) << "\n";
  }

  return 0;
}