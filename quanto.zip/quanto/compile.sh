#!/bin/bash

set -e 

RAWR="$(pwd)/rawr"
RAWR_DIST="${RAWR}/dist"

cd $RAWR
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=./dist
cmake --build build
cmake --install build

cd ..

g++ -std=c++20 -Wall -Wextra -Wpedantic -O3 -I $RAWR_DIST/include -I $RAWR_DIST/sha3/include -I $RAWR_DIST/RandomShake/include -I $RAWR_DIST/subtle/include -L/usr/lib -lssl -lcrypto main.cpp
FLAG="flag{test_not_the_real_flag}" ./a.out
